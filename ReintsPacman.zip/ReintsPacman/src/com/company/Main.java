package com.company;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Main {

    /**
     * Small console program that:
     * - contains a data structure for the maze in pac-man
     * - provides main method that reads in a maze definition and creates the maze data structure
     * - prints data structure information
     * - support loading mazes from some data store(we will use text files)
     *
     * @param args: filename for input text
     * @author reint
     * @since 2018-05-01
     */
    public static void main (String[] args) {
        // TODO: read the name of an input file
        try {
            new FileInputStream (args[0]);
        } catch (FileNotFoundException e) {
            // text file could not be found - check that full path is specified
            e.printStackTrace ();
        }

        // TODO: Create maze data structure
        Maze maze = new Maze (args[0]);
        //maze dimensions
        maze.getDimensions ();
        //start for ghost
        maze.getGhost ();
        //start for pacman
        maze.getPac ();




    }


}
