package com.company;

import javafx.geometry.Point2D;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The pac-man maze is represented as a simple x,y grid of tiles. The entire maze is X tiles wide by Y tiles high.
 * Each tile is either a wall or a hallway. We are not concerned with the orientation of walls.
 *
 * @author reint
 * @since 2018-05-01
 */
class Maze {
    // TODO 1 - output the dimensions of the maze
    // TODO 2 - output if a given [x,y] tile represents a hallway or a wall
    // TODO 3 - output what moves are possible from a given tile.
    // TODO 4 - support loading mazes from some data store (we will use text files)

    private Point2D ghost;
    private Point2D pac;
    private int x_dimensions;
    private int y_dimensions;

    /**
     * @param fileName - input file will be a simple ASCII text file. Hallways are denoted with space characters, and
     *                 the '$' char denotes a wall. Pac-man's initial position is marked with the upper case letter
     *                 'P', and the ghost's position is marked with an upper case 'G'. Each row of tiles will end
     *                 with carriage return.
     */
    Maze (String fileName) {

        //initialize grid for maze

        //initialize file and scanner  using input fileName/path
        File file = new File (fileName);
        Scanner scan = null;
        try {
            scan = new Scanner (file);
        } catch (FileNotFoundException e) {
            e.printStackTrace ();
        }

        //scan all lines of text file: currently prints the current line
        assert scan != null;
        Point2D pacman;
        Point2D ghost;
        int x_dim = 0;
        int y_dim = 0;
        ArrayList <Tile> grid = new ArrayList <> ();
        while (scan.hasNextLine ()) {
            //scan the next line and assign it to a temporary string
            String temp = scan.nextLine ();

            //TEST: print maze
            //find x dimension
            if (x_dim == 0) {
                x_dim = temp.length ();
            }
            //where's Tupacman
            if (temp.contains ("P")) {
                pacman = new Point2D (temp.indexOf ("P") + 1, y_dim + 1);
                this.pac = pacman;
            }
            //where's ghost - can't use else if in case g and point are in the same row
            if (temp.contains ("G")) {
                ghost = new Point2D (temp.indexOf ("G") + 1, y_dim + 1);
                this.ghost = ghost;
            }

            //create tile objects
            char[] line = temp.toCharArray ();
            for (int i = 0; i < line.length; i++) {
                Point2D p = new Point2D (i + 1, y_dim + 1);
                Tile tile = new Tile (p, line[i]);
                grid.add (tile);

                this.getMoves ();
            }
            //find y dimension
            y_dim += 1;
        }

        this.x_dimensions = x_dim;
        this.y_dimensions = y_dim;


        //final assignments/outputs
        //System.out.printf ("\n1- Maze Dimensions: %dx%d%n", x_dim, y_dim);
        //System.out.printf ("2- Pacman Start: %s%n", pacman);
        //System.out.printf ("3- Ghost Start: %s%n", ghost);
        //System.out.println (new Tile (Pacman, ' ').getMoves (Pacman));

    }

    private void getMoves () {

    }

    void getGhost () {
        System.out.println (this.ghost);
    }

    void getPac () {
        System.out.println (this.pac);
    }

    void getDimensions () {
        System.out.println (this.x_dimensions + "x" + this.y_dimensions);

    }

}
