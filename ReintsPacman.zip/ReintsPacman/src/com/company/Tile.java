package com.company;

import javafx.geometry.Point2D;

import java.util.ArrayList;

/**
 * Individual tiles. Each tile has an associated x,y coordinate and a type (i.e. Wall, Hallway, Ghost, Pac-man, etc.)
 */
public class Tile {
    Point2D point;
    String type;
    ArrayList moves;

    public Tile (Point2D point, char character) {

        this.point = point;
        this.type = getType (character);
        this.moves = getMoves (this.point);
    }

    public String getTileValue () {
        return this.type;
    }

    public ArrayList getMoves (Point2D tile) {

        return null;
    }


    public String getType (char character) {
        switch (character) {
            case '$':
                return "wall";
            case 'P':
                return "Pac-man";
            case 'G':
                return "Ghost";
            case ' ':
                return "Open";
            case '\n':
                return "End-Line";
            default:
                return "N/A";
        }
    }
}
